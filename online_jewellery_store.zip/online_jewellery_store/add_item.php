<?php
    require 'connection.php';
    session_start();
?>
<!DOCTYPE html>
<html>
    <head>
        <link rel="shortcut icon" href="img/lifestyleStore.png" />
        <title>Online Watch Store</title>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <!-- latest compiled and minified CSS -->
        <link rel="stylesheet" href="bootstrap/css/bootstrap.min.css" type="text/css">
        <!-- jquery library -->
        <script type="text/javascript" src="bootstrap/js/jquery-3.2.1.min.js"></script>
        <!-- Latest compiled and minified javascript -->
        <script type="text/javascript" src="bootstrap/js/bootstrap.min.js"></script>
        <!-- External CSS -->
        <link rel="stylesheet" href="css/style.css" type="text/css">
    </head>
    <body>
        <div>            
            <br><br><br>
           <div class="container">
                <div class="row">
                    <div class="col-xs-6 col-xs-offset-3">
                        <div class="panel panel-primary">
                            <div class="panel-heading">
                                <h3>ADD ITEMS</h3>
                            </div>
                            <div id="menubar">
                              <ul id="menu">
                                <!-- put class="selected" in the li tag for the selected page - to highlight which page you're on -->
                                <!-- <li class="selected"><a href="index.html">Home</a></li> -->
                                <li><a href="admin_dashboard.php">DASHBOARD</a></li>
                                <li><a href="add_item.php">ADD ITEMS</a></li>
                                <li><a href="delete_item.php">DELETE</a></li>
                                <li><a href="modify_item.php">MODIFY</a></li>
                                <li><a href="view_customers.php">CUSTOMERS</a></li>                        
                                <li><a href="logout.php">LOGOUT</a></li>         
                              </ul>
                          </div> 
                            <div class="panel-body">                                
                                <form method="post" action="add_this_item.php" enctype="multipart/form-data">
                                    <div class="form-group">
                                        Item Name : <input type="text" class="form-control" name="itemname">
                                    </div>
                                    <div class="form-group">
                                        Item Image : <input type="file" name="Filename" accept="image/*">
                                    </div>                                    
                                    <div class="form-group">
                                        Item Price : <input type="text" class="form-control" name="itemprice">
                                    </div>
                                    <div class="form-group">
                                        <input type="submit" value="Add Item" class="btn btn-primary">
                                    </div>
                                </form>
                            </div>                            
                        </div>
                    </div>
                </div>
           </div>
           <br><br><br><br><br>
           <footer class="footer">
               <div class="container">
                <center>
                   <p>Copyright &copy <a href="index.php">Mrinal</a>&nbsp;&nbsp; 2019.</p>
                   <p>Designed by Mrinal</p>
               </center>
               </div>
           </footer>
        </div>
    </body>
</html>
