<?php
session_start();
require_once 'connection.php';
$username 	 = $_POST['username'];
$password  = $_POST['password'];
$sql   = "SELECT * FROM admin WHERE username ='$username' AND password ='$password'";
$result = mysqli_query($con,$sql);
$count  = mysqli_num_rows($result);
$row    = mysqli_fetch_array($result);
if($count==1){  
  $_SESSION["admin"] = $row[username];
  header("location: admin_dashboard.php");
}
else{
  $error = "Your username and password is incorrect";
  echo $error;
}
?>
