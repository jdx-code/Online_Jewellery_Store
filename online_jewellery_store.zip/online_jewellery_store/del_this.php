<?php
require_once 'connection.php';

$id  = $_GET['id'];
$sql = "DELETE FROM items where id = '$id'";
$query = mysqli_query($con,$sql);
header('Location: delete_item.php');
?>
