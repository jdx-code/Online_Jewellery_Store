<?php
    session_start();
    require 'check_if_added.php';
    require_once 'connection.php';
?>
<!DOCTYPE html>
<html>
    <head>
        <link rel="shortcut icon" href="img/lifestyleStore.png" />
        <title>Online Watch Store</title>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <!-- latest compiled and minified CSS -->
        <link rel="stylesheet" href="bootstrap/css/bootstrap.min.css" type="text/css">
        <!-- jquery library -->
        <script type="text/javascript" src="bootstrap/js/jquery-3.2.1.min.js"></script>
        <!-- Latest compiled and minified javascript -->
        <script type="text/javascript" src="bootstrap/js/bootstrap.min.js"></script>
        <!-- External CSS -->
        <link rel="stylesheet" href="css/style.css" type="text/css">
    </head>
    <body>
        <div>
            <?php
                require 'header.php';
            ?>

            <div class="container">
                <div class="jumbotron">
                    <h1>Online Watch Store!</h1>
                    <p>Best Watches, all in one place.</p>
                </div>
            </div> 

            <div class="container">
                <div class="row">
                    <?php
                        $sql   = "SELECT * FROM items ORDER BY id DESC";
                        $result = mysqli_query($con,$sql);       
                        while($row = mysqli_fetch_array($result)){
                    ?>  
                    <div class="col-md-3">
                        <div class="thumbnail">
                            <a href="">
                                <img src="<?php echo $row['filepath'];?>" style="width:300px;height:130px;">
                            </a>
                        </div>
                        <center>
                            <div class="caption">
                                <h3><?php echo $row['name'];?></h3>
                                <p><?php echo $row['price'];?></p>
                                <a href="del_this.php?id=<?php echo $row['id']?>" class="btn btn-block btn-primary" name="add" value="add" class="btn btn-block btr-primary">DELETE</a>
                            </div>
                        </center>
                    </div>  
                    <?php
                    }
                ?>
                </div>
            </div>
            <p>
                <center><a href="products.php">PREVIOUS</a></center>
            </p>             
           <footer class="footer">
               <div class="container">
                <center>
                   <p>Copyright &copy <a href="index.php">Mrinal</a>&nbsp;&nbsp; 2019.</p>
                   <p>Designed by Mrinal</p>
               </center>
               </div>
           </footer>
        </div>
    </body>
</html>
