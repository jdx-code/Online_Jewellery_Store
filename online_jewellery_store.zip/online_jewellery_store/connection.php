<?php
	$con=mysqli_connect("localhost","root","","db_jewellery_store") or die(mysqli_error($con));
?>
