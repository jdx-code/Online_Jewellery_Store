<?php
	require_once 'connection.php';
	//$fileExistsFlag = 0; 
	$fileName = $_FILES['Filename']['name'];
	/* 
	*	Checking whether the file already exists in the destination folder 
	*/

	$sql = "SELECT filename FROM items WHERE filename='$fileName'";	
	$result = mysqli_query($con,$sql);
	$count  = mysqli_num_rows($result);
	$row = mysqli_fetch_array($result);
	if($count==1){

		$fileExistsFlag = 1;	
	}
	/*
	* 	If file is not present in the destination folder
	*/
	// if($fileExistsFlag == 0) { 
		$target = "files/";		
		$fileTarget = $target.$fileName;	
		$tempFileName 	= $_FILES["Filename"]["tmp_name"];
		$itemname 		= $_POST['itemname'];
		$itemprice 		= $_POST['itemprice'];		
		
		$result = move_uploaded_file($tempFileName,$fileTarget);
		/*
		*	If file was successfully uploaded in the destination folder
		*/
		if($result) { 
			echo "Your file <html><b><i>".$fileName."</i></b></html> has been successfully uploaded";		
			$sql = "INSERT INTO items(id,name,price,filepath,filename) VALUES (DEFAULT, '$itemname', '$itemprice', '$fileTarget','$fileName')";
			mysqli_query($con,$sql);			
		}
		else {			
			echo "Sorry !!! There was an error in uploading your file";			
		}
		mysqli_close($con);	
?>