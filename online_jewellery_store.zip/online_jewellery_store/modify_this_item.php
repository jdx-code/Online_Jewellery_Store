<?php
  session_start();
  
  require_once 'connection.php';

  $item_id = $_POST['item_id'];
  $fname   = $_POST['fname'];
  $price   = $_POST['price'];
  
  $sql   =  "UPDATE items SET              
             name  = '$fname',
             price = '$price'
             WHERE id = '$item_id'";
  $query = mysqli_query($con,$sql);
  header('Location: modify_item.php');
?>